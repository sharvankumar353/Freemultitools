import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "@/components/ui/theme-provider";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";

// Import auth pages
import Login from "./pages/Auth/Login";
import Signup from "./pages/Auth/Signup";

// Import tool pages
import ImageToText from "./pages/tools/ImageToText";
import ImageConverter from "./pages/tools/ImageConverter";
import ImageCompressor from "./pages/tools/ImageCompressor";
import ImageResizer from "./pages/tools/ImageResizer";
import ImageResizerKB from "./pages/tools/ImageResizerKB";
import PdfToJpg from "./pages/tools/PdfToJpg";
import PdfMerger from "./pages/tools/PdfMerger";
import PdfSplitter from "./pages/tools/PdfSplitter";
import PdfToPng from "./pages/tools/PdfToPng";
import QrCodeGenerator from "./pages/tools/QrCodeGenerator";
import SipCalculator from "./pages/tools/SipCalculator";
import CompoundInterest from "./pages/tools/CompoundInterest";
import LoanEmiCalculator from "./pages/tools/LoanEmiCalculator";
import GstCalculator from "./pages/tools/GstCalculator";
import PrivacyPolicyGenerator from "./pages/tools/PrivacyPolicyGenerator";
import PasswordGenerator from "./pages/tools/PasswordGenerator";
import MetaTagsGenerator from "./pages/tools/MetaTagsGenerator";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider defaultTheme="light">
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            
            {/* Auth Routes */}
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />

            {/* Tool Routes */}
            <Route path="/tools/image-to-text" element={<ImageToText />} />
            <Route path="/tools/image-converter" element={<ImageConverter />} />
            <Route path="/tools/image-compressor" element={<ImageCompressor />} />
            <Route path="/tools/image-resizer" element={<ImageResizer />} />
            <Route path="/tools/20kb-image-resizer" element={<ImageResizerKB />} />
            <Route path="/tools/pdf-to-jpg" element={<PdfToJpg />} />
            <Route path="/tools/pdf-merger" element={<PdfMerger />} />
            <Route path="/tools/pdf-splitter" element={<PdfSplitter />} />
            <Route path="/tools/pdf-to-png" element={<PdfToPng />} />
            <Route path="/tools/qr-code-generator" element={<QrCodeGenerator />} />
            <Route path="/tools/sip-calculator" element={<SipCalculator />} />
            <Route path="/tools/compound-interest" element={<CompoundInterest />} />
            <Route path="/tools/loan-emi-calculator" element={<LoanEmiCalculator />} />
            <Route path="/tools/gst-calculator" element={<GstCalculator />} />
            <Route path="/tools/privacy-policy-generator" element={<PrivacyPolicyGenerator />} />
            <Route path="/tools/password-generator" element={<PasswordGenerator />} />
            <Route path="/tools/meta-tags-generator" element={<MetaTagsGenerator />} />
            
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
