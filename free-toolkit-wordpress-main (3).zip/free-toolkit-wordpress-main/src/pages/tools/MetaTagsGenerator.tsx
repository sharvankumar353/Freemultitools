
import { useState } from "react";
import ToolLayout from "../../components/layout/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Copy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const MetaTagsGenerator = () => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [keywords, setKeywords] = useState("");
  const [author, setAuthor] = useState("");
  const [ogTitle, setOgTitle] = useState("");
  const [ogDescription, setOgDescription] = useState("");
  const [ogImage, setOgImage] = useState("");
  
  const [generatedTags, setGeneratedTags] = useState("");
  const { toast } = useToast();

  const generateMetaTags = () => {
    if (!title || !description) {
      toast({
        title: "Missing information",
        description: "Title and description are required",
        variant: "destructive",
      });
      return;
    }

    let metaTags = `<!-- Primary Meta Tags -->\n`;
    metaTags += `<title>${title}</title>\n`;
    metaTags += `<meta name="title" content="${title}">\n`;
    metaTags += `<meta name="description" content="${description}">\n`;
    
    if (keywords) {
      metaTags += `<meta name="keywords" content="${keywords}">\n`;
    }
    
    if (author) {
      metaTags += `<meta name="author" content="${author}">\n`;
    }
    
    // Open Graph / Facebook
    if (ogTitle || ogDescription || ogImage) {
      metaTags += `\n<!-- Open Graph / Facebook -->\n`;
      metaTags += `<meta property="og:type" content="website">\n`;
      if (ogTitle || title) {
        metaTags += `<meta property="og:title" content="${ogTitle || title}">\n`;
      }
      if (ogDescription || description) {
        metaTags += `<meta property="og:description" content="${ogDescription || description}">\n`;
      }
      if (ogImage) {
        metaTags += `<meta property="og:image" content="${ogImage}">\n`;
      }
    }
    
    // Twitter
    if (ogTitle || ogDescription || ogImage) {
      metaTags += `\n<!-- Twitter -->\n`;
      metaTags += `<meta property="twitter:card" content="summary_large_image">\n`;
      if (ogTitle || title) {
        metaTags += `<meta property="twitter:title" content="${ogTitle || title}">\n`;
      }
      if (ogDescription || description) {
        metaTags += `<meta property="twitter:description" content="${ogDescription || description}">\n`;
      }
      if (ogImage) {
        metaTags += `<meta property="twitter:image" content="${ogImage}">\n`;
      }
    }
    
    setGeneratedTags(metaTags);
    toast({
      title: "Meta tags generated",
      description: "Your SEO meta tags have been created successfully",
    });
  };
  
  const copyToClipboard = () => {
    if (!generatedTags) return;
    
    navigator.clipboard.writeText(generatedTags).then(() => {
      toast({
        title: "Copied to clipboard",
        description: "Meta tags have been copied to clipboard",
      });
    });
  };

  return (
    <ToolLayout title="SEO Meta Tags Generator">
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <p className="text-gray-600 mb-6">
            Create optimized meta tags for your website to improve SEO and social media sharing. Generate HTML meta tags for search engines and social platforms.
          </p>
          
          <div className="space-y-4 mb-6">
            <div>
              <Label htmlFor="title">Title (required)</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Your page title"
              />
            </div>
            
            <div>
              <Label htmlFor="description">Description (required)</Label>
              <textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Brief description of your page"
                className="w-full p-2 border border-gray-300 rounded-md"
                rows={3}
              />
            </div>
            
            <div>
              <Label htmlFor="keywords">Keywords (comma separated)</Label>
              <Input
                id="keywords"
                value={keywords}
                onChange={(e) => setKeywords(e.target.value)}
                placeholder="keyword1, keyword2, keyword3"
              />
            </div>
            
            <div>
              <Label htmlFor="author">Author</Label>
              <Input
                id="author"
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                placeholder="Page author name"
              />
            </div>
            
            <h3 className="font-medium text-gray-700 mt-6">Social Media (Open Graph)</h3>
            
            <div>
              <Label htmlFor="ogTitle">OG Title (optional, uses main title if empty)</Label>
              <Input
                id="ogTitle"
                value={ogTitle}
                onChange={(e) => setOgTitle(e.target.value)}
                placeholder="Title for social media sharing"
              />
            </div>
            
            <div>
              <Label htmlFor="ogDescription">OG Description (optional, uses main description if empty)</Label>
              <textarea
                id="ogDescription"
                value={ogDescription}
                onChange={(e) => setOgDescription(e.target.value)}
                placeholder="Description for social media sharing"
                className="w-full p-2 border border-gray-300 rounded-md"
                rows={2}
              />
            </div>
            
            <div>
              <Label htmlFor="ogImage">OG Image URL</Label>
              <Input
                id="ogImage"
                value={ogImage}
                onChange={(e) => setOgImage(e.target.value)}
                placeholder="https://example.com/image.jpg"
              />
            </div>
          </div>
          
          <Button onClick={generateMetaTags} className="w-full">Generate Meta Tags</Button>
          
          {generatedTags && (
            <div className="mt-8 pt-6 border-t">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-medium">Your Meta Tags</h3>
                <Button onClick={copyToClipboard} size="sm" className="inline-flex items-center gap-2">
                  <Copy size={16} />
                  Copy to Clipboard
                </Button>
              </div>
              
              <div className="border rounded-md p-4 bg-gray-50">
                <pre className="whitespace-pre-wrap text-sm overflow-x-auto text-gray-700">{generatedTags}</pre>
              </div>
            </div>
          )}
        </div>
      </div>
    </ToolLayout>
  );
};

export default MetaTagsGenerator;
