
import ToolLayout from "../../components/layout/ToolLayout";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Upload, FileImage, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const ImageConverter = () => {
  const [file, setFile] = useState<File | null>(null);
  const [outputFormat, setOutputFormat] = useState("png");
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const convertFile = () => {
    if (!file) {
      toast({
        title: "No file selected",
        description: "Please upload an image first",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    
    // In a real implementation, this would convert the image
    // For now, we'll simulate processing with a timeout
    setTimeout(() => {
      setIsProcessing(false);
      toast({
        title: "Conversion complete",
        description: `Your image has been converted to ${outputFormat.toUpperCase()} format`,
      });
    }, 2000);
  };

  return (
    <ToolLayout title="Image Converter">
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="mb-6">
            <p className="text-gray-600 mb-4">
              Convert your images between different formats including PNG, JPG, WEBP, and more.
            </p>
            
            <label className="block mb-4">
              <div className="flex items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                <div className="flex flex-col items-center justify-center">
                  <FileImage className="h-8 w-8 text-gray-400 mb-2" />
                  <span className="text-sm text-gray-500">
                    {file ? file.name : "Upload an image"}
                  </span>
                </div>
                <input
                  type="file"
                  className="hidden"
                  onChange={handleFileUpload}
                  accept="image/*"
                />
              </div>
            </label>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Output Format
              </label>
              <select
                className="w-full p-2 border border-gray-300 rounded-md"
                value={outputFormat}
                onChange={(e) => setOutputFormat(e.target.value)}
              >
                <option value="png">PNG</option>
                <option value="jpg">JPG</option>
                <option value="webp">WEBP</option>
                <option value="gif">GIF</option>
              </select>
            </div>

            <Button 
              onClick={convertFile} 
              disabled={!file || isProcessing}
              className="w-full"
            >
              {isProcessing ? "Converting..." : "Convert Image"}
            </Button>
          </div>

          {isProcessing && (
            <div className="flex justify-center my-4">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
            </div>
          )}

          {!isProcessing && file && (
            <div className="border rounded-md p-4 bg-gray-50 text-center">
              <Button disabled className="inline-flex items-center gap-2">
                <Download size={16} />
                Download Converted Image
              </Button>
              <p className="text-xs text-gray-500 mt-2">
                (This is a demo. In a production environment, actual conversion would occur.)
              </p>
            </div>
          )}
        </div>
      </div>
    </ToolLayout>
  );
};

export default ImageConverter;
