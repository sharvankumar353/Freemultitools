
import ToolLayout from "../../components/layout/ToolLayout";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { FileImage, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const ImageResizerKB = () => {
  const [file, setFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const resizeImage = () => {
    if (!file) {
      toast({
        title: "No file selected",
        description: "Please upload an image first",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    
    // In a real implementation, this would resize the image
    // For now, we'll simulate processing with a timeout
    setTimeout(() => {
      setIsProcessing(false);
      toast({
        title: "Resize complete",
        description: "Your image has been resized to approximately 20KB",
      });
    }, 2000);
  };

  return (
    <ToolLayout title="20KB Image Resizer">
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="mb-6">
            <p className="text-gray-600 mb-4">
              Resize your images to approximately 20KB. Perfect for profile pictures, avatars, and other web applications with strict file size limits.
            </p>
            
            <label className="block mb-4">
              <div className="flex items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                <div className="flex flex-col items-center justify-center">
                  <FileImage className="h-8 w-8 text-gray-400 mb-2" />
                  <span className="text-sm text-gray-500">
                    {file ? file.name : "Upload an image"}
                  </span>
                </div>
                <input
                  type="file"
                  className="hidden"
                  onChange={handleFileUpload}
                  accept="image/*"
                />
              </div>
            </label>

            <Button 
              onClick={resizeImage} 
              disabled={!file || isProcessing}
              className="w-full"
            >
              {isProcessing ? "Resizing..." : "Resize to 20KB"}
            </Button>
          </div>

          {isProcessing && (
            <div className="flex justify-center my-4">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
            </div>
          )}

          {!isProcessing && file && (
            <div className="border rounded-md p-4 bg-gray-50 text-center">
              <Button disabled className="inline-flex items-center gap-2">
                <Download size={16} />
                Download Resized Image
              </Button>
              <p className="text-xs text-gray-500 mt-2">
                (This is a demo. In a production environment, actual resizing would occur.)
              </p>
            </div>
          )}
        </div>
      </div>
    </ToolLayout>
  );
};

export default ImageResizerKB;
