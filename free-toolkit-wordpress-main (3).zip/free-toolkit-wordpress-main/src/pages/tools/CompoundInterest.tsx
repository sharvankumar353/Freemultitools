
import { useState } from "react";
import ToolLayout from "../../components/layout/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const CompoundInterest = () => {
  const [principal, setPrincipal] = useState(10000);
  const [rate, setRate] = useState(8);
  const [time, setTime] = useState(5);
  const [compoundFrequency, setCompoundFrequency] = useState(1);
  const [result, setResult] = useState<{
    finalAmount: number;
    interestEarned: number;
  } | null>(null);

  const handleCalculate = () => {
    // Formula: P(1 + r/n)^(nt)
    // where P is principal, r is rate, n is compound frequency, and t is time
    const p = principal;
    const r = rate / 100;
    const t = time;
    const n = compoundFrequency;
    
    const finalAmount = p * Math.pow(1 + (r / n), n * t);
    const interestEarned = finalAmount - p;
    
    setResult({
      finalAmount,
      interestEarned,
    });
  };
  
  return (
    <ToolLayout title="Compound Interest Calculator">
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <p className="text-gray-600 mb-6">
            Calculate how your investment grows over time with compound interest. Enter your initial investment amount, interest rate, time period, and compounding frequency to see the results.
          </p>
          
          <div className="space-y-4 mb-6">
            <div>
              <Label htmlFor="principal">Initial Investment (₹)</Label>
              <Input
                id="principal"
                type="number"
                value={principal}
                onChange={(e) => setPrincipal(parseInt(e.target.value) || 0)}
              />
            </div>
            
            <div>
              <Label htmlFor="rate">Annual Interest Rate (%)</Label>
              <Input
                id="rate"
                type="number"
                value={rate}
                onChange={(e) => setRate(parseFloat(e.target.value) || 0)}
              />
            </div>
            
            <div>
              <Label htmlFor="time">Time Period (Years)</Label>
              <Input
                id="time"
                type="number"
                value={time}
                onChange={(e) => setTime(parseInt(e.target.value) || 0)}
              />
            </div>
            
            <div>
              <Label htmlFor="compoundFrequency">Compounding Frequency</Label>
              <select
                id="compoundFrequency"
                className="w-full p-2 border border-gray-300 rounded-md"
                value={compoundFrequency}
                onChange={(e) => setCompoundFrequency(parseInt(e.target.value))}
              >
                <option value={1}>Annually</option>
                <option value={2}>Semi-Annually</option>
                <option value={4}>Quarterly</option>
                <option value={12}>Monthly</option>
                <option value={365}>Daily</option>
              </select>
            </div>
          </div>
          
          <Button onClick={handleCalculate} className="w-full">Calculate</Button>
          
          {result && (
            <div className="mt-8 pt-6 border-t">
              <h3 className="text-xl font-medium mb-4">Results</h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-center">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-500">Final Amount</p>
                  <p className="text-xl font-bold">₹{Math.round(result.finalAmount).toLocaleString()}</p>
                </div>
                
                <div className="bg-green-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-500">Interest Earned</p>
                  <p className="text-xl font-bold">₹{Math.round(result.interestEarned).toLocaleString()}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </ToolLayout>
  );
};

export default CompoundInterest;
