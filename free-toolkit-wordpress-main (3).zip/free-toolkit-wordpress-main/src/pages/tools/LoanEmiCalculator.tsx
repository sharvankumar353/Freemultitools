
import { useState } from "react";
import ToolLayout from "../../components/layout/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const LoanEmiCalculator = () => {
  const [loanAmount, setLoanAmount] = useState(1000000);
  const [interestRate, setInterestRate] = useState(10);
  const [tenureYears, setTenureYears] = useState(20);
  const [result, setResult] = useState<{
    monthlyEmi: number;
    totalInterest: number;
    totalPayment: number;
  } | null>(null);

  const handleCalculate = () => {
    // Formula: EMI = [P x R x (1+R)^N]/[(1+R)^N-1]
    // where P is principal, R is rate per month, and N is number of months
    const p = loanAmount;
    const r = interestRate / 1200; // monthly interest rate
    const n = tenureYears * 12; // total number of months
    
    const monthlyEmi = (p * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    const totalPayment = monthlyEmi * n;
    const totalInterest = totalPayment - p;
    
    setResult({
      monthlyEmi,
      totalInterest,
      totalPayment,
    });
  };
  
  return (
    <ToolLayout title="Loan EMI Calculator">
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <p className="text-gray-600 mb-6">
            Calculate your monthly loan EMI (Equated Monthly Installment) and total interest payable based on loan amount, interest rate, and tenure.
          </p>
          
          <div className="space-y-4 mb-6">
            <div>
              <Label htmlFor="loanAmount">Loan Amount (₹)</Label>
              <Input
                id="loanAmount"
                type="number"
                value={loanAmount}
                onChange={(e) => setLoanAmount(parseInt(e.target.value) || 0)}
              />
            </div>
            
            <div>
              <Label htmlFor="interestRate">Interest Rate (% per annum)</Label>
              <Input
                id="interestRate"
                type="number"
                value={interestRate}
                onChange={(e) => setInterestRate(parseFloat(e.target.value) || 0)}
              />
            </div>
            
            <div>
              <Label htmlFor="tenureYears">Loan Tenure (Years)</Label>
              <Input
                id="tenureYears"
                type="number"
                value={tenureYears}
                onChange={(e) => setTenureYears(parseInt(e.target.value) || 0)}
              />
            </div>
          </div>
          
          <Button onClick={handleCalculate} className="w-full">Calculate EMI</Button>
          
          {result && (
            <div className="mt-8 pt-6 border-t">
              <h3 className="text-xl font-medium mb-4">Loan Summary</h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-500">Monthly EMI</p>
                  <p className="text-xl font-bold">₹{Math.round(result.monthlyEmi).toLocaleString()}</p>
                </div>
                
                <div className="bg-green-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-500">Total Interest</p>
                  <p className="text-xl font-bold">₹{Math.round(result.totalInterest).toLocaleString()}</p>
                </div>
                
                <div className="bg-purple-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-500">Total Payment</p>
                  <p className="text-xl font-bold">₹{Math.round(result.totalPayment).toLocaleString()}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </ToolLayout>
  );
};

export default LoanEmiCalculator;
