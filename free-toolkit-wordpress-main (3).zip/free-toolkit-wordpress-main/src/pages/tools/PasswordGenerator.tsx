
import { useState } from "react";
import ToolLayout from "../../components/layout/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Copy, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const PasswordGenerator = () => {
  const [password, setPassword] = useState("");
  const [length, setLength] = useState(12);
  const [includeUppercase, setIncludeUppercase] = useState(true);
  const [includeLowercase, setIncludeLowercase] = useState(true);
  const [includeNumbers, setIncludeNumbers] = useState(true);
  const [includeSymbols, setIncludeSymbols] = useState(true);
  const { toast } = useToast();

  const generatePassword = () => {
    let charset = "";
    if (includeUppercase) charset += "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    if (includeLowercase) charset += "abcdefghijklmnopqrstuvwxyz";
    if (includeNumbers) charset += "0123456789";
    if (includeSymbols) charset += "!@#$%^&*()_+{}[]|:;<>,.?/~";
    
    if (charset === "") {
      toast({
        title: "No character set selected",
        description: "Please select at least one character type",
        variant: "destructive",
      });
      return;
    }
    
    let newPassword = "";
    for (let i = 0; i < length; i++) {
      newPassword += charset.charAt(Math.floor(Math.random() * charset.length));
    }
    
    setPassword(newPassword);
  };
  
  const copyToClipboard = () => {
    if (!password) return;
    
    navigator.clipboard.writeText(password).then(() => {
      toast({
        title: "Password copied",
        description: "Password has been copied to clipboard",
      });
    });
  };

  return (
    <ToolLayout title="Password Generator">
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <p className="text-gray-600 mb-6">
            Generate secure, random passwords with customizable options. Choose length and character types to create strong passwords for your accounts.
          </p>
          
          {/* Password Output */}
          <div className="mb-6">
            <div className="relative">
              <Input
                value={password}
                readOnly
                placeholder="Your password will appear here"
                className="pr-24 font-mono text-lg"
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2 flex space-x-1">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={generatePassword}
                  className="h-8 w-8 p-0"
                  title="Generate new password"
                >
                  <RefreshCw size={16} />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={copyToClipboard}
                  disabled={!password}
                  className="h-8 w-8 p-0"
                  title="Copy to clipboard"
                >
                  <Copy size={16} />
                </Button>
              </div>
            </div>
          </div>
          
          {/* Options */}
          <div className="space-y-4 mb-6">
            <div>
              <Label htmlFor="length">Password Length: {length}</Label>
              <div className="flex items-center space-x-2">
                <input
                  id="length"
                  type="range"
                  min="6"
                  max="32"
                  value={length}
                  onChange={(e) => setLength(parseInt(e.target.value))}
                  className="flex-1"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="includeUppercase"
                  checked={includeUppercase}
                  onChange={() => setIncludeUppercase(!includeUppercase)}
                  className="mr-2"
                />
                <Label htmlFor="includeUppercase">Uppercase Letters (A-Z)</Label>
              </div>
              
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="includeLowercase"
                  checked={includeLowercase}
                  onChange={() => setIncludeLowercase(!includeLowercase)}
                  className="mr-2"
                />
                <Label htmlFor="includeLowercase">Lowercase Letters (a-z)</Label>
              </div>
              
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="includeNumbers"
                  checked={includeNumbers}
                  onChange={() => setIncludeNumbers(!includeNumbers)}
                  className="mr-2"
                />
                <Label htmlFor="includeNumbers">Numbers (0-9)</Label>
              </div>
              
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="includeSymbols"
                  checked={includeSymbols}
                  onChange={() => setIncludeSymbols(!includeSymbols)}
                  className="mr-2"
                />
                <Label htmlFor="includeSymbols">Symbols (!@#$%^&*)</Label>
              </div>
            </div>
          </div>
          
          <Button onClick={generatePassword} className="w-full">Generate Password</Button>
          
          {password && (
            <div className="mt-6 pt-6 border-t">
              <h3 className="text-lg font-medium mb-2">Password Strength</h3>
              <div className="bg-gray-100 h-2 rounded-full overflow-hidden">
                <div 
                  className={`h-full ${
                    length < 8 ? "bg-red-500" : 
                    length < 12 ? "bg-yellow-500" : 
                    "bg-green-500"
                  }`}
                  style={{ width: `${Math.min(100, (length / 32) * 100)}%` }}
                />
              </div>
              <p className="text-sm text-gray-500 mt-2">
                {length < 8 ? "Weak" : length < 12 ? "Moderate" : "Strong"} password
              </p>
            </div>
          )}
        </div>
      </div>
    </ToolLayout>
  );
};

export default PasswordGenerator;
