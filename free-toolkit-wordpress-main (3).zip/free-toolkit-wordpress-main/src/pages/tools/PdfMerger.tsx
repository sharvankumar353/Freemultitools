
import ToolLayout from "../../components/layout/ToolLayout";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { FileText, Plus, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const PdfMerger = () => {
  const [files, setFiles] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(prev => [...prev, ...Array.from(e.target.files || [])]);
    }
  };

  const removeFile = (index: number) => {
    setFiles(files.filter((_, i) => i !== index));
  };

  const mergePdfs = () => {
    if (files.length < 2) {
      toast({
        title: "Not enough files",
        description: "Please upload at least 2 PDF files to merge",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    
    // In a real implementation, this would merge the PDFs
    // For now, we'll simulate processing with a timeout
    setTimeout(() => {
      setIsProcessing(false);
      toast({
        title: "Merge complete",
        description: "Your PDF files have been merged successfully",
      });
    }, 2000);
  };

  return (
    <ToolLayout title="PDF Merger">
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="mb-6">
            <p className="text-gray-600 mb-4">
              Combine multiple PDF files into a single document. Upload two or more PDFs and arrange them in your preferred order.
            </p>
            
            <label className="block mb-4">
              <div className="flex items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                <div className="flex flex-col items-center justify-center">
                  <Plus className="h-8 w-8 text-gray-400 mb-2" />
                  <span className="text-sm text-gray-500">
                    Add PDF files
                  </span>
                </div>
                <input
                  type="file"
                  className="hidden"
                  onChange={handleFileUpload}
                  accept=".pdf"
                  multiple
                />
              </div>
            </label>

            {files.length > 0 && (
              <div className="mb-4 border rounded-md p-3">
                <h3 className="font-medium text-gray-700 mb-2">Files to merge ({files.length})</h3>
                <ul className="space-y-2">
                  {files.map((file, index) => (
                    <li key={index} className="flex items-center justify-between bg-gray-50 p-2 rounded">
                      <div className="flex items-center">
                        <FileText className="h-5 w-5 text-gray-500 mr-2" />
                        <span className="text-sm text-gray-700 truncate max-w-xs">{file.name}</span>
                      </div>
                      <button 
                        onClick={() => removeFile(index)}
                        className="text-red-500 hover:text-red-700 text-sm"
                      >
                        Remove
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <Button 
              onClick={mergePdfs} 
              disabled={files.length < 2 || isProcessing}
              className="w-full"
            >
              {isProcessing ? "Merging..." : "Merge PDFs"}
            </Button>
          </div>

          {isProcessing && (
            <div className="flex justify-center my-4">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
            </div>
          )}

          {!isProcessing && files.length >= 2 && (
            <div className="border rounded-md p-4 bg-gray-50 text-center">
              <Button disabled className="inline-flex items-center gap-2">
                <Download size={16} />
                Download Merged PDF
              </Button>
              <p className="text-xs text-gray-500 mt-2">
                (This is a demo. In a production environment, actual PDF merging would occur.)
              </p>
            </div>
          )}
        </div>
      </div>
    </ToolLayout>
  );
};

export default PdfMerger;
