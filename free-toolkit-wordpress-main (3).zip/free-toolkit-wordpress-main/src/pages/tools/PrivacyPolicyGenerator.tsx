
import { useState } from "react";
import ToolLayout from "../../components/layout/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const PrivacyPolicyGenerator = () => {
  const [companyName, setCompanyName] = useState("");
  const [websiteUrl, setWebsiteUrl] = useState("");
  const [email, setEmail] = useState("");
  const [collectsPersonalData, setCollectsPersonalData] = useState(true);
  const [generatedPolicy, setGeneratedPolicy] = useState("");
  const { toast } = useToast();

  const generatePolicy = () => {
    if (!companyName || !websiteUrl || !email) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    // Generate a basic privacy policy template
    const policy = `
# Privacy Policy for ${companyName}

Last updated: ${new Date().toLocaleDateString()}

## Introduction

${companyName} ("we," "our," or "us") operates the website ${websiteUrl} (the "Service"). This page informs you of our policies regarding the collection, use, and disclosure of personal data when you use our Service and the choices you have associated with that data.

## Information Collection and Use

${collectsPersonalData 
  ? `We collect several different types of information for various purposes to provide and improve our Service to you.

### Personal Data

While using our Service, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you ("Personal Data"). Personally identifiable information may include, but is not limited to:
- Email address
- First name and last name
- Phone number
- Address, State, Province, ZIP/Postal code, City
- Cookies and Usage Data`
  : `We do not collect personally identifiable information from users of our Service.`}

## Contact Us

If you have any questions about this Privacy Policy, please contact us:
- By email: ${email}
- By visiting this page on our website: ${websiteUrl}/contact

    `;

    setGeneratedPolicy(policy);
    toast({
      title: "Privacy policy generated",
      description: "Your custom privacy policy has been created successfully",
    });
  };

  return (
    <ToolLayout title="Privacy Policy Generator">
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <p className="text-gray-600 mb-6">
            Create a customized privacy policy for your website or app. Fill in your details below to generate a privacy policy document that helps you comply with laws like GDPR, CCPA, and more.
          </p>
          
          <div className="space-y-4 mb-6">
            <div>
              <Label htmlFor="companyName">Company/Website Name *</Label>
              <Input
                id="companyName"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                placeholder="Your Company Name"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="websiteUrl">Website URL *</Label>
              <Input
                id="websiteUrl"
                value={websiteUrl}
                onChange={(e) => setWebsiteUrl(e.target.value)}
                placeholder="https://yourwebsite.com"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="email">Contact Email *</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="privacy@yourwebsite.com"
                required
              />
            </div>
            
            <div className="flex items-center">
              <input
                type="checkbox"
                id="collectsPersonalData"
                checked={collectsPersonalData}
                onChange={() => setCollectsPersonalData(!collectsPersonalData)}
                className="mr-2"
              />
              <Label htmlFor="collectsPersonalData">Website collects personal information</Label>
            </div>
          </div>
          
          <Button onClick={generatePolicy} className="w-full">Generate Privacy Policy</Button>
          
          {generatedPolicy && (
            <div className="mt-8 pt-6 border-t">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-medium">Your Privacy Policy</h3>
                <Button disabled className="inline-flex items-center gap-2">
                  <Download size={16} />
                  Download as PDF
                </Button>
              </div>
              
              <div className="border rounded-md p-4 bg-gray-50">
                <pre className="whitespace-pre-wrap text-sm text-gray-700">{generatedPolicy}</pre>
              </div>
            </div>
          )}
        </div>
      </div>
    </ToolLayout>
  );
};

export default PrivacyPolicyGenerator;
