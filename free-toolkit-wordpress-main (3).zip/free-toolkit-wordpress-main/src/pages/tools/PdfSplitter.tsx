
import ToolLayout from "../../components/layout/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { FileText, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const PdfSplitter = () => {
  const [file, setFile] = useState<File | null>(null);
  const [pageRange, setPageRange] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const splitPdf = () => {
    if (!file) {
      toast({
        title: "No file selected",
        description: "Please upload a PDF file first",
        variant: "destructive",
      });
      return;
    }

    if (!pageRange.trim()) {
      toast({
        title: "No page range specified",
        description: "Please enter the pages you want to extract",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    
    // In a real implementation, this would split the PDF
    // For now, we'll simulate processing with a timeout
    setTimeout(() => {
      setIsProcessing(false);
      toast({
        title: "Split complete",
        description: `Pages ${pageRange} have been extracted from your PDF file`,
      });
    }, 2000);
  };

  return (
    <ToolLayout title="PDF Splitter">
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="mb-6">
            <p className="text-gray-600 mb-4">
              Extract specific pages from a PDF document. Upload a PDF file and specify which pages you want to extract.
            </p>
            
            <label className="block mb-4">
              <div className="flex items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                <div className="flex flex-col items-center justify-center">
                  <FileText className="h-8 w-8 text-gray-400 mb-2" />
                  <span className="text-sm text-gray-500">
                    {file ? file.name : "Upload a PDF file"}
                  </span>
                </div>
                <input
                  type="file"
                  className="hidden"
                  onChange={handleFileUpload}
                  accept=".pdf"
                />
              </div>
            </label>

            <div className="mb-4">
              <Label htmlFor="pageRange">Pages to extract</Label>
              <Input
                id="pageRange"
                placeholder="e.g., 1-3, 5, 7-9"
                value={pageRange}
                onChange={(e) => setPageRange(e.target.value)}
              />
              <p className="text-xs text-gray-500 mt-1">
                Enter page numbers and/or ranges separated by commas
              </p>
            </div>

            <Button 
              onClick={splitPdf} 
              disabled={!file || !pageRange || isProcessing}
              className="w-full"
            >
              {isProcessing ? "Extracting..." : "Extract Pages"}
            </Button>
          </div>

          {isProcessing && (
            <div className="flex justify-center my-4">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
            </div>
          )}

          {!isProcessing && file && pageRange && (
            <div className="border rounded-md p-4 bg-gray-50 text-center">
              <Button disabled className="inline-flex items-center gap-2">
                <Download size={16} />
                Download Extracted Pages
              </Button>
              <p className="text-xs text-gray-500 mt-2">
                (This is a demo. In a production environment, actual PDF splitting would occur.)
              </p>
            </div>
          )}
        </div>
      </div>
    </ToolLayout>
  );
};

export default PdfSplitter;
