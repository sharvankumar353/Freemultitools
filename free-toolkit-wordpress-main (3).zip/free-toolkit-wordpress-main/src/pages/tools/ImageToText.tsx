
import ToolLayout from "../../components/layout/ToolLayout";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Upload } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const ImageToText = () => {
  const [image, setImage] = useState<File | null>(null);
  const [text, setText] = useState<string>("");
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setImage(e.target.files[0]);
      setText(""); // Reset text when new image is uploaded
    }
  };

  const processImage = () => {
    if (!image) {
      toast({
        title: "No image selected",
        description: "Please upload an image first",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    
    // In a real implementation, this would call an OCR API
    // For now, we'll simulate processing with a timeout
    setTimeout(() => {
      setText("This is placeholder text extracted from your image. In a real application, this would be the actual text extracted using an OCR API.");
      setIsProcessing(false);
      toast({
        title: "Processing complete",
        description: "Text has been extracted from your image",
      });
    }, 2000);
  };

  return (
    <ToolLayout title="AI Image to Text Converter">
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="mb-6">
            <p className="text-gray-600 mb-4">
              Extract text from images using our AI-powered OCR technology. Upload an image containing text, and our tool will convert it to editable text.
            </p>
            
            <label className="block mb-4">
              <div className="flex items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                <div className="flex flex-col items-center justify-center">
                  <Upload className="h-8 w-8 text-gray-400 mb-2" />
                  <span className="text-sm text-gray-500">
                    {image ? image.name : "Upload an image"}
                  </span>
                </div>
                <input
                  type="file"
                  className="hidden"
                  onChange={handleImageUpload}
                  accept="image/*"
                />
              </div>
            </label>

            <Button 
              onClick={processImage} 
              disabled={!image || isProcessing}
              className="w-full"
            >
              {isProcessing ? "Processing..." : "Extract Text"}
            </Button>
          </div>

          {text && (
            <div className="border rounded-md p-4 bg-gray-50">
              <h3 className="text-lg font-medium mb-2">Extracted Text:</h3>
              <p className="whitespace-pre-wrap text-gray-700">{text}</p>
            </div>
          )}
        </div>
      </div>
    </ToolLayout>
  );
};

export default ImageToText;
