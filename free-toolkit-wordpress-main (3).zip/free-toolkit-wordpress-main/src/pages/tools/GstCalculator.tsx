
import { useState } from "react";
import ToolLayout from "../../components/layout/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const GstCalculator = () => {
  const [amount, setAmount] = useState(1000);
  const [gstRate, setGstRate] = useState(18);
  const [isGstIncluded, setIsGstIncluded] = useState(false);
  const [result, setResult] = useState<{
    baseAmount: number;
    gstAmount: number;
    totalAmount: number;
  } | null>(null);

  const handleCalculate = () => {
    let baseAmount: number;
    let gstAmount: number;
    let totalAmount: number;
    
    if (isGstIncluded) {
      // GST already included in the amount
      baseAmount = amount / (1 + gstRate / 100);
      gstAmount = amount - baseAmount;
      totalAmount = amount;
    } else {
      // GST to be added to the amount
      baseAmount = amount;
      gstAmount = amount * (gstRate / 100);
      totalAmount = amount + gstAmount;
    }
    
    setResult({
      baseAmount,
      gstAmount,
      totalAmount,
    });
  };
  
  return (
    <ToolLayout title="GST Calculator">
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <p className="text-gray-600 mb-6">
            Calculate GST amounts for your invoices. Enter the amount, GST rate, and specify whether GST is already included or needs to be added.
          </p>
          
          <div className="space-y-4 mb-6">
            <div>
              <Label htmlFor="amount">Amount (₹)</Label>
              <Input
                id="amount"
                type="number"
                value={amount}
                onChange={(e) => setAmount(parseInt(e.target.value) || 0)}
              />
            </div>
            
            <div>
              <Label htmlFor="gstRate">GST Rate (%)</Label>
              <select
                id="gstRate"
                className="w-full p-2 border border-gray-300 rounded-md"
                value={gstRate}
                onChange={(e) => setGstRate(parseInt(e.target.value))}
              >
                <option value={0}>0% (GST Exempt)</option>
                <option value={5}>5% GST</option>
                <option value={12}>12% GST</option>
                <option value={18}>18% GST</option>
                <option value={28}>28% GST</option>
              </select>
            </div>
            
            <div className="flex items-center">
              <input
                type="checkbox"
                id="isGstIncluded"
                checked={isGstIncluded}
                onChange={() => setIsGstIncluded(!isGstIncluded)}
                className="mr-2"
              />
              <Label htmlFor="isGstIncluded">GST included in amount</Label>
            </div>
          </div>
          
          <Button onClick={handleCalculate} className="w-full">Calculate GST</Button>
          
          {result && (
            <div className="mt-8 pt-6 border-t">
              <h3 className="text-xl font-medium mb-4">GST Calculation</h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-500">Base Amount</p>
                  <p className="text-xl font-bold">₹{result.baseAmount.toFixed(2)}</p>
                </div>
                
                <div className="bg-green-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-500">GST Amount ({gstRate}%)</p>
                  <p className="text-xl font-bold">₹{result.gstAmount.toFixed(2)}</p>
                </div>
                
                <div className="bg-purple-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-500">Total Amount</p>
                  <p className="text-xl font-bold">₹{result.totalAmount.toFixed(2)}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </ToolLayout>
  );
};

export default GstCalculator;
