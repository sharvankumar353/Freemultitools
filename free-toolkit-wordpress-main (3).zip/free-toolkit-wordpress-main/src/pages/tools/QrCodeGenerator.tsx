
import ToolLayout from "../../components/layout/ToolLayout";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { QrCode, Download } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const QrCodeGenerator = () => {
  const [text, setText] = useState("");
  const [qrGenerated, setQrGenerated] = useState(false);
  const { toast } = useToast();

  const generateQR = () => {
    if (!text) {
      toast({
        title: "No text entered",
        description: "Please enter some text to generate a QR code",
        variant: "destructive",
      });
      return;
    }

    setQrGenerated(true);
    toast({
      title: "QR Code generated",
      description: "Your QR code has been created successfully",
    });
  };

  return (
    <ToolLayout title="QR Code Generator">
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="mb-6">
            <p className="text-gray-600 mb-4">
              Generate QR codes for URLs, text, or contact information. Simply enter your content and create a downloadable QR code image.
            </p>
            
            <div className="mb-4">
              <label htmlFor="qr-content" className="block text-sm font-medium text-gray-700 mb-1">
                QR Code Content
              </label>
              <textarea
                id="qr-content"
                className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows={4}
                placeholder="Enter URL, text, or contact information"
                value={text}
                onChange={(e) => setText(e.target.value)}
              ></textarea>
            </div>

            <Button 
              onClick={generateQR} 
              disabled={!text}
              className="w-full"
            >
              Generate QR Code
            </Button>
          </div>

          {qrGenerated && (
            <div className="border rounded-md p-4 bg-gray-50 text-center">
              <div className="flex flex-col items-center">
                <QrCode size={200} className="mb-4" />
                <Button className="inline-flex items-center gap-2">
                  <Download size={16} />
                  Download QR Code
                </Button>
                <p className="text-xs text-gray-500 mt-2">
                  (This is a demo QR code. In a production environment, a real QR code would be generated based on your input.)
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </ToolLayout>
  );
};

export default QrCodeGenerator;
