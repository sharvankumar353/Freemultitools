
import { useState } from "react";
import ToolLayout from "../../components/layout/ToolLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const SipCalculator = () => {
  const [monthlyInvestment, setMonthlyInvestment] = useState(5000);
  const [years, setYears] = useState(10);
  const [interestRate, setInterestRate] = useState(12);
  const [result, setResult] = useState<{
    totalInvestment: number;
    estimatedReturns: number;
    totalValue: number;
  } | null>(null);

  const handleCalculate = () => {
    // Formula: M × {[(1 + r)^t - 1] / r} × (1 + r)
    // where M is monthly investment, r is rate of interest per month, and t is time in months
    const r = interestRate / 100 / 12;
    const t = years * 12;
    
    const totalInvestment = monthlyInvestment * t;
    const totalValue = monthlyInvestment * (((Math.pow(1 + r, t) - 1) / r) * (1 + r));
    const estimatedReturns = totalValue - totalInvestment;
    
    setResult({
      totalInvestment,
      estimatedReturns,
      totalValue,
    });
  };
  
  return (
    <ToolLayout title="SIP Calculator">
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <p className="text-gray-600 mb-6">
            Calculate the potential returns on your Systematic Investment Plan (SIP). Enter your monthly investment amount, time period, and expected annual return rate to see how your investment could grow over time.
          </p>
          
          <div className="space-y-4 mb-6">
            <div>
              <Label htmlFor="monthlyInvestment">Monthly Investment (₹)</Label>
              <Input
                id="monthlyInvestment"
                type="number"
                value={monthlyInvestment}
                onChange={(e) => setMonthlyInvestment(parseInt(e.target.value) || 0)}
              />
            </div>
            
            <div>
              <Label htmlFor="years">Investment Period (Years)</Label>
              <Input
                id="years"
                type="number"
                value={years}
                onChange={(e) => setYears(parseInt(e.target.value) || 0)}
              />
            </div>
            
            <div>
              <Label htmlFor="interestRate">Expected Annual Return (%)</Label>
              <Input
                id="interestRate"
                type="number"
                value={interestRate}
                onChange={(e) => setInterestRate(parseInt(e.target.value) || 0)}
              />
            </div>
          </div>
          
          <Button onClick={handleCalculate} className="w-full">Calculate</Button>
          
          {result && (
            <div className="mt-8 pt-6 border-t">
              <h3 className="text-xl font-medium mb-4">Results</h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-500">Amount Invested</p>
                  <p className="text-xl font-bold">₹{result.totalInvestment.toLocaleString()}</p>
                </div>
                
                <div className="bg-green-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-500">Estimated Returns</p>
                  <p className="text-xl font-bold">₹{Math.round(result.estimatedReturns).toLocaleString()}</p>
                </div>
                
                <div className="bg-purple-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-500">Total Value</p>
                  <p className="text-xl font-bold">₹{Math.round(result.totalValue).toLocaleString()}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </ToolLayout>
  );
};

export default SipCalculator;
