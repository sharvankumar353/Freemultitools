
import { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Navbar from './Navbar';
import Footer from './Footer';

interface ToolLayoutProps {
  children: ReactNode;
  title: string;
}

const ToolLayout = ({ children, title }: ToolLayoutProps) => {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900">
      <Navbar />
      <main className="flex-grow py-8">
        <div className="container mx-auto px-4">
          <div className="mb-6">
            <Button
              variant="outline"
              size="sm"
              className="flex items-center gap-1"
              asChild
            >
              <Link to="/">
                <ArrowLeft size={16} />
                Back to Tools
              </Link>
            </Button>
          </div>
          <h1 className="text-3xl font-bold mb-8 text-center dark:text-white">{title}</h1>
          {children}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ToolLayout;
