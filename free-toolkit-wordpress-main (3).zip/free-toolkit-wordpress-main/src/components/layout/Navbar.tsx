
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ChevronDown, LogIn, UserPlus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ThemeToggle from '@/components/ui/ThemeToggle';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";

type MenuItemProps = {
  title: string;
  submenu?: { title: string; path: string }[];
};

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeSubmenu, setActiveSubmenu] = useState<string | null>(null);
  const navigate = useNavigate();

  const menuItems: MenuItemProps[] = [
    { title: 'Home' },
    { 
      title: 'Image Tools',
      submenu: [
        { title: 'AI Image to Text', path: '/tools/image-to-text' },
        { title: 'Image Converter', path: '/tools/image-converter' },
        { title: 'Image Compressor', path: '/tools/image-compressor' },
        { title: 'Image Resizer', path: '/tools/image-resizer' },
        { title: '20KB Image Resizer', path: '/tools/20kb-image-resizer' }
      ]
    },
    { 
      title: 'PDF Tools',
      submenu: [
        { title: 'PDF to JPG', path: '/tools/pdf-to-jpg' },
        { title: 'PDF Merger', path: '/tools/pdf-merger' },
        { title: 'PDF Splitter', path: '/tools/pdf-splitter' },
        { title: 'PDF to PNG', path: '/tools/pdf-to-png' },
        { title: 'PDF to WEBP', path: '/tools/pdf-to-webp' },
        { title: 'PDF Watermark', path: '/tools/pdf-watermark' },
        { title: 'PDF to ZIP', path: '/tools/pdf-to-zip' },
        { title: 'DOC to PDF', path: '/tools/doc-to-pdf' }
      ]
    },
    { 
      title: 'Calculator Tools',
      submenu: [
        { title: 'SIP Calculator', path: '/tools/sip-calculator' },
        { title: 'Compound Interest', path: '/tools/compound-interest' },
        { title: 'Loan EMI Calculator', path: '/tools/loan-emi-calculator' },
        { title: 'GST Calculator', path: '/tools/gst-calculator' },
        { title: 'Simple Interest', path: '/tools/simple-interest' },
        { title: 'Fiverr Fee Calculator', path: '/tools/fiverr-fee-calculator' }
      ]
    }
  ];

  const handleSubmenu = (title: string) => {
    setActiveSubmenu(activeSubmenu === title ? null : title);
  };

  const handleLogin = () => {
    navigate('/login');
  };

  const handleSignup = () => {
    navigate('/signup');
  };

  // Render desktop dropdown menu
  const renderDesktopDropdownMenu = (item: MenuItemProps) => {
    if (!item.submenu) {
      return (
        <Link to="/" className="px-3 py-2 hover:bg-tool-blue rounded">
          {item.title}
        </Link>
      );
    }
    
    return (
      <DropdownMenu>
        <DropdownMenuTrigger className="flex items-center px-3 py-2 text-white hover:bg-tool-blue rounded">
          {item.title}
          <ChevronDown size={16} className="ml-1" />
        </DropdownMenuTrigger>
        <DropdownMenuContent className="bg-white text-gray-800 w-48 z-50">
          {item.submenu.map((subItem) => (
            <DropdownMenuItem key={subItem.path} asChild>
              <Link to={subItem.path} className="w-full">
                {subItem.title}
              </Link>
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    );
  };

  return (
    <nav className="bg-tool-navyBlue dark:bg-gray-900 text-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-1">
              <span className="text-2xl font-bold">freeMulti<span className="text-tool-accent">Tools</span></span>
              <div className="ml-1 text-xs bg-green-500 py-0.5 px-1 rounded-sm relative top-[-8px]">β</div>
            </Link>
            <span className="text-xs text-gray-400 ml-1 hidden sm:block">Powerful Free Online Tools</span>
          </div>

          {/* Auth Buttons - Mobile */}
          <div className="flex items-center space-x-2 md:hidden mr-4">
            <Button size="sm" variant="outline" onClick={handleLogin} className="text-white border-white hover:bg-tool-blue dark:hover:bg-gray-700 flex items-center gap-1">
              <LogIn className="h-4 w-4" />
              <span>Log in</span>
            </Button>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex space-x-4">
            {menuItems.map((item) => (
              <div key={item.title} className="relative inline-block">
                {renderDesktopDropdownMenu(item)}
              </div>
            ))}
          </div>

          {/* Theme Toggle and Auth Buttons - Desktop */}
          <div className="hidden md:flex items-center space-x-3">
            <ThemeToggle />
            <Button size="sm" variant="outline" onClick={handleLogin} className="text-white border-white hover:bg-tool-blue dark:hover:bg-gray-700 flex items-center gap-1">
              <LogIn className="h-4 w-4" />
              <span>Log in</span>
            </Button>
            <Button size="sm" onClick={handleSignup} className="bg-tool-accent hover:bg-tool-accent/90 text-white flex items-center gap-1">
              <UserPlus className="h-4 w-4" />
              <span>Sign up</span>
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center gap-2">
            <ThemeToggle />
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-white focus:outline-none"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                {isOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path>
                )}
              </svg>
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden pb-4">
            {menuItems.map((item) => (
              <div key={item.title} className="mt-1">
                {item.submenu ? (
                  <>
                    <button
                      onClick={() => handleSubmenu(item.title)}
                      className="w-full text-left px-4 py-2 flex justify-between items-center hover:bg-tool-blue rounded"
                    >
                      {item.title}
                      <ChevronDown size={16} className={`${activeSubmenu === item.title ? 'transform rotate-180' : ''}`} />
                    </button>
                    {activeSubmenu === item.title && (
                      <div className="pl-4 bg-tool-blue bg-opacity-50 rounded mt-1">
                        {item.submenu.map((subItem) => (
                          <Link
                            key={subItem.title}
                            to={subItem.path}
                            className="block px-4 py-2 hover:bg-tool-blue rounded"
                            onClick={() => setIsOpen(false)}
                          >
                            {subItem.title}
                          </Link>
                        ))}
                      </div>
                    )}
                  </>
                ) : (
                  <Link to="/" className="block px-4 py-2 hover:bg-tool-blue rounded" onClick={() => setIsOpen(false)}>
                    {item.title}
                  </Link>
                )}
              </div>
            ))}
            
            {/* Auth buttons in mobile menu */}
            <div className="mt-4 flex flex-col space-y-2 px-4">
              <Button variant="outline" onClick={handleLogin} className="w-full text-white border-white hover:bg-tool-blue flex items-center justify-center gap-1">
                <LogIn className="h-4 w-4" />
                <span>Log in</span>
              </Button>
              <Button onClick={handleSignup} className="w-full bg-tool-accent hover:bg-tool-accent/90 text-white flex items-center justify-center gap-1">
                <UserPlus className="h-4 w-4" />
                <span>Sign up</span>
              </Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
