
import SearchBar from '../ui/SearchBar';

const HeroSection = () => {
  return (
    <div className="bg-gradient-to-br from-tool-navyBlue to-tool-blue py-16 text-white relative overflow-hidden">
      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-7/12 mb-8 md:mb-0 animate-fade-in">
            <h1 className="text-4xl sm:text-5xl font-bold mb-6">
              Professional <span className="text-tool-accent">Tools</span><br />
              at Your Fingertips
            </h1>
            <p className="text-xl mb-8 text-gray-200 max-w-xl">
              Transform your workflow with our suite of powerful online tools. No downloads required, just click and use.
            </p>
            
            <SearchBar />
          </div>
          <div className="md:w-5/12 flex justify-center md:justify-end">
            <img 
              src="https://images.unsplash.com/photo-1581092795360-fd1ca04f0952?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=MnwyMDg3MDd8MHwxfHJhbmRvbXx8fHx8fHx8fDE2MjM2Njk3NzI&ixlib=rb-1.2.1&q=80&w=400"
              alt="Person using laptop with tools"
              className="rounded-lg shadow-xl max-w-full md:max-w-sm"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;
