
import { 
  Image, 
  FileImage, 
  Compass, // Changed from Compress to Compass 
  Calculator,
  QrCode,
  Edit,
  FileText, // Changed from FilePdf to FileText
  Download,
  Upload 
} from 'lucide-react';
import CategoryHeader from '../ui/CategoryHeader';
import ToolCard from '../ui/ToolCard';

const ToolsSection = () => {
  const imageTools = [
    {
      title: 'AI Image to Text',
      path: '/tools/image-to-text',
      icon: <Edit size={32} />
    },
    {
      title: 'Image Converter',
      path: '/tools/image-converter',
      icon: <FileImage size={32} />
    },
    {
      title: 'Image Compressor',
      path: '/tools/image-compressor',
      icon: <Compass size={32} /> // Updated to use Compass instead of Compress
    },
    {
      title: 'Image Resizer',
      path: '/tools/image-resizer',
      icon: <Image size={32} />
    },
    {
      title: '20KB Image Resizer',
      path: '/tools/20kb-image-resizer',
      icon: <Image size={32} />
    }
  ];

  const pdfTools = [
    {
      title: 'PDF to JPG',
      path: '/tools/pdf-to-jpg',
      icon: <FileImage size={32} />
    },
    {
      title: 'PDF Merger',
      path: '/tools/pdf-merger',
      icon: <FileText size={32} /> // Updated to use FileText instead of FilePdf
    },
    {
      title: 'PDF Splitter',
      path: '/tools/pdf-splitter',
      icon: <FileText size={32} /> // Updated to use FileText instead of FilePdf
    },
    {
      title: 'PDF to PNG',
      path: '/tools/pdf-to-png',
      icon: <FileImage size={32} />
    }
  ];

  const calculatorTools = [
    {
      title: 'SIP Calculator',
      path: '/tools/sip-calculator',
      icon: <Calculator size={32} />
    },
    {
      title: 'Compound Interest',
      path: '/tools/compound-interest',
      icon: <Calculator size={32} />
    },
    {
      title: 'Loan EMI Calculator',
      path: '/tools/loan-emi-calculator',
      icon: <Calculator size={32} />
    },
    {
      title: 'GST Calculator',
      path: '/tools/gst-calculator',
      icon: <Calculator size={32} />
    }
  ];

  const generatorTools = [
    {
      title: 'QR Code Generator',
      path: '/tools/qr-code-generator',
      icon: <QrCode size={32} />
    },
    {
      title: 'Privacy Policy Generator',
      path: '/tools/privacy-policy-generator',
      icon: <Download size={32} />
    },
    {
      title: 'Password Generator',
      path: '/tools/password-generator',
      icon: <Upload size={32} />
    },
    {
      title: 'SEO Meta Tags Generator',
      path: '/tools/meta-tags-generator',
      icon: <FileImage size={32} />
    }
  ];

  return (
    <div className="py-8">
      <CategoryHeader title="Image Tools" />
      <div className="container mx-auto px-4 mb-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
          {imageTools.map((tool) => (
            <ToolCard
              key={tool.path}
              title={tool.title}
              path={tool.path}
              icon={tool.icon}
            />
          ))}
        </div>
      </div>

      <CategoryHeader title="PDF Tools" />
      <div className="container mx-auto px-4 mb-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {pdfTools.map((tool) => (
            <ToolCard
              key={tool.path}
              title={tool.title}
              path={tool.path}
              icon={tool.icon}
            />
          ))}
        </div>
      </div>

      <CategoryHeader title="Calculator Tools" />
      <div className="container mx-auto px-4 mb-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {calculatorTools.map((tool) => (
            <ToolCard
              key={tool.path}
              title={tool.title}
              path={tool.path}
              icon={tool.icon}
            />
          ))}
        </div>
      </div>

      <CategoryHeader title="Generator Tools" />
      <div className="container mx-auto px-4 mb-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {generatorTools.map((tool) => (
            <ToolCard
              key={tool.path}
              title={tool.title}
              path={tool.path}
              icon={tool.icon}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default ToolsSection;
