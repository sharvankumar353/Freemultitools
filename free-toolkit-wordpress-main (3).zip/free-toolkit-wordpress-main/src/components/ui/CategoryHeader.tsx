
type CategoryHeaderProps = {
  title: string;
};

const CategoryHeader = ({ title }: CategoryHeaderProps) => {
  return (
    <div className="category-header">
      <div className="container mx-auto px-4">
        <h2>{title}</h2>
      </div>
    </div>
  );
};

export default CategoryHeader;
