
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search } from 'lucide-react';
import { CommandSearch } from './CommandSearch';

type SearchBarProps = {
  placeholder?: string;
  onSearch?: (query: string) => void;
};

const SearchBar = ({ placeholder = "Search tools (e.g., 'PDF converter', 'image resizer')...", onSearch }: SearchBarProps) => {
  const [query, setQuery] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearch) {
      onSearch(query);
    }
  };

  return (
    <div className="relative w-full max-w-xl mx-auto">
      <CommandSearch />
    </div>
  );
};

export default SearchBar;
