
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import {
  Command,
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList
} from '@/components/ui/command';
import { Button } from '@/components/ui/button';

// Define the structure of a tool
type Tool = {
  title: string;
  path: string;
  category: string;
};

export function CommandSearch() {
  const [open, setOpen] = useState(false);
  const [searchValue, setSearchValue] = useState('');
  const navigate = useNavigate();

  // Combined list of all tools
  const allTools: Tool[] = [
    // Image Tools
    { title: 'AI Image to Text', path: '/tools/image-to-text', category: 'Image Tools' },
    { title: 'Image Converter', path: '/tools/image-converter', category: 'Image Tools' },
    { title: 'Image Compressor', path: '/tools/image-compressor', category: 'Image Tools' },
    { title: 'Image Resizer', path: '/tools/image-resizer', category: 'Image Tools' },
    { title: '20KB Image Resizer', path: '/tools/20kb-image-resizer', category: 'Image Tools' },
    
    // PDF Tools
    { title: 'PDF to JPG', path: '/tools/pdf-to-jpg', category: 'PDF Tools' },
    { title: 'PDF Merger', path: '/tools/pdf-merger', category: 'PDF Tools' },
    { title: 'PDF Splitter', path: '/tools/pdf-splitter', category: 'PDF Tools' },
    { title: 'PDF to PNG', path: '/tools/pdf-to-png', category: 'PDF Tools' },
    { title: 'PDF to WEBP', path: '/tools/pdf-to-webp', category: 'PDF Tools' },
    { title: 'PDF Watermark', path: '/tools/pdf-watermark', category: 'PDF Tools' },
    { title: 'PDF to ZIP', path: '/tools/pdf-to-zip', category: 'PDF Tools' },
    { title: 'DOC to PDF', path: '/tools/doc-to-pdf', category: 'PDF Tools' },
    
    // Calculator Tools
    { title: 'SIP Calculator', path: '/tools/sip-calculator', category: 'Calculator Tools' },
    { title: 'Compound Interest', path: '/tools/compound-interest', category: 'Calculator Tools' },
    { title: 'Loan EMI Calculator', path: '/tools/loan-emi-calculator', category: 'Calculator Tools' },
    { title: 'GST Calculator', path: '/tools/gst-calculator', category: 'Calculator Tools' },
    { title: 'Simple Interest', path: '/tools/simple-interest', category: 'Calculator Tools' },
    { title: 'Fiverr Fee Calculator', path: '/tools/fiverr-fee-calculator', category: 'Calculator Tools' },
    
    // Generator Tools
    { title: 'QR Code Generator', path: '/tools/qr-code-generator', category: 'Generator Tools' },
    { title: 'Privacy Policy Generator', path: '/tools/privacy-policy-generator', category: 'Generator Tools' },
    { title: 'Password Generator', path: '/tools/password-generator', category: 'Generator Tools' },
    { title: 'SEO Meta Tags Generator', path: '/tools/meta-tags-generator', category: 'Generator Tools' }
  ];

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((open) => !open);
      }
    };

    document.addEventListener('keydown', down);
    return () => document.removeEventListener('keydown', down);
  }, []);

  const handleSelect = (tool: Tool) => {
    navigate(tool.path);
    setOpen(false);
    setSearchValue('');
  };

  return (
    <>
      <Button
        variant="outline"
        className="relative h-10 w-full justify-start bg-white dark:bg-gray-800 text-gray-500 dark:text-gray-300 sm:w-64 md:w-96"
        onClick={() => setOpen(true)}
      >
        <Search className="mr-2 h-4 w-4" />
        <span>Search tools...</span>
        <kbd className="pointer-events-none absolute right-2 top-2 hidden h-6 select-none items-center gap-1 rounded border bg-background px-2 font-mono text-xs md:flex">
          <span className="text-xs">⌘</span>K
        </kbd>
      </Button>
      <CommandDialog open={open} onOpenChange={setOpen}>
        <Command shouldFilter={false}>
          <CommandInput 
            placeholder="Type to search..." 
            value={searchValue}
            onValueChange={setSearchValue}
          />
          <CommandList>
            <CommandEmpty>No results found.</CommandEmpty>
            <CommandGroup>
              {allTools
                .filter(tool => 
                  tool.title.toLowerCase().includes(searchValue.toLowerCase()) ||
                  tool.category.toLowerCase().includes(searchValue.toLowerCase())
                )
                .map((tool) => (
                  <CommandItem 
                    key={tool.path}
                    onSelect={() => handleSelect(tool)}
                    className="cursor-pointer"
                  >
                    <span className="font-medium">{tool.title}</span>
                    <span className="ml-2 text-xs text-gray-400">{tool.category}</span>
                  </CommandItem>
                ))
              }
            </CommandGroup>
          </CommandList>
        </Command>
      </CommandDialog>
    </>
  );
}
