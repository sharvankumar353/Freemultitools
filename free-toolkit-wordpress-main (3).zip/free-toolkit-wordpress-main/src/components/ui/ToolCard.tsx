
import { Link } from 'react-router-dom';

type ToolCardProps = {
  title: string;
  path: string;
  icon: React.ReactNode;
};

const ToolCard = ({ title, path, icon }: ToolCardProps) => {
  return (
    <Link to={path} className="tool-card group">
      <div className="tool-icon-container text-tool-blue">{icon}</div>
      <h3 className="text-center text-gray-700 group-hover:text-tool-accent">{title}</h3>
    </Link>
  );
};

export default ToolCard;
